var searchData=
[
  ['p',['P',['../classsp_1_1_f_i_r__filt.html#a890e05333fd14871ab8bb8336227d0b0',1,'sp::FIR_filt::P()'],['../group__kalman.html#gae3021e62dafa67abcb401202fb918655',1,'sp::KF::P()'],['../classsp_1_1resampling.html#a1e67777fa504b4cd2b52f9d74c4069a6',1,'sp::resampling::P()']]],
  ['par_5fmap',['par_map',['../classsp_1_1parser.html#aeb5e47dbf42795afb988f3d60f8fd8f7',1,'sp::parser']]],
  ['pi',['PI',['../group__math.html#ga034dbffa92d82e870d4cc1a9c5b9ac07',1,'sp']]],
  ['pi_5f2',['PI_2',['../group__math.html#ga9fd397ecb93b285615809a1018268ed7',1,'sp']]],
  ['pl_5ffft',['pl_fft',['../classsp_1_1_f_f_t_w.html#ab67577c12d73b1d9ee70e98e335b8181',1,'sp::FFTW']]],
  ['pl_5ffft_5fcx',['pl_fft_cx',['../classsp_1_1_f_f_t_w.html#a088b7747a48a667c1ae4b951bea7bd64',1,'sp::FFTW']]],
  ['pl_5fifft',['pl_ifft',['../classsp_1_1_f_f_t_w.html#a2bc1158c58a2d3f1a9fd143305761798',1,'sp::FFTW']]],
  ['pl_5fifft_5fcx',['pl_ifft_cx',['../classsp_1_1_f_f_t_w.html#a6b1bbba54d8edfb1550fc27639bf897a',1,'sp::FFTW']]],
  ['plot_5fix',['plot_ix',['../classsp_1_1gplot.html#a1dfdc12a81e08edfc42d76ca5cb23a7a',1,'sp::gplot']]],
  ['plotlist',['plotlist',['../classsp_1_1gplot.html#aeec70f138e99d52a6a723b5dccd42877',1,'sp::gplot']]]
];
