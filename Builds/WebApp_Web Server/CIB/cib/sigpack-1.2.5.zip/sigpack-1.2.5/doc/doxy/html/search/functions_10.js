var searchData=
[
  ['read',['read',['../classsp_1_1_p_n_m.html#ae07ff403c0c264e09d0d914700a602de',1,'sp::PNM::read(std::string fname, arma::cube &amp;img)'],['../classsp_1_1_p_n_m.html#a6c26ae9eaf931250bd3307f198b55f84',1,'sp::PNM::read(std::string fname, arma::mat &amp;img)']]],
  ['read_5fheader',['read_header',['../classsp_1_1_p_n_m.html#aeed21cdf4fc66c405108120103c0b49c',1,'sp::PNM']]],
  ['resampling',['resampling',['../classsp_1_1resampling.html#ac88f61062f995e695516768da7fc2e87',1,'sp::resampling::resampling(const arma::uword _P, const arma::uword _Q, const arma::vec _H)'],['../classsp_1_1resampling.html#a59d26a96d716ee2cf65fa2eab19e1a9b',1,'sp::resampling::resampling(const arma::uword _P, const arma::uword _Q)']]],
  ['reset_5fterm',['reset_term',['../classsp_1_1gplot.html#a5975e2a9c0cde793ba51f6ebf1fea4ba',1,'sp::gplot']]],
  ['rls_5fadapt',['rls_adapt',['../classsp_1_1_f_i_r__filt.html#a8681459dc2fb617ce88b7d05a30ea88d',1,'sp::FIR_filt']]],
  ['rts_5fsmooth',['rts_smooth',['../group__kalman.html#ga25a30e70231f98665db7e72ccf3b537b',1,'sp::KF::rts_smooth()'],['../group__kalman.html#ga5f7b89dc24cafe87253b4ae7ab6dd984',1,'sp::EKF::rts_smooth()'],['../group__kalman.html#ga0da8be50ff45663f10273fd655b46986',1,'sp::UKF::rts_smooth()']]]
];
