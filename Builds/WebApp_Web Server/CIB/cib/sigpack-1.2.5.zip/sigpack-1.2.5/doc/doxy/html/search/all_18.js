var searchData=
[
  ['ylabel',['ylabel',['../classsp_1_1gplot.html#a4f607335b244f7d32e97cec042a40909',1,'sp::gplot']]],
  ['ylim',['ylim',['../classsp_1_1gplot.html#a6a4f61481914abbb232df33630913a7f',1,'sp::gplot']]]
];
