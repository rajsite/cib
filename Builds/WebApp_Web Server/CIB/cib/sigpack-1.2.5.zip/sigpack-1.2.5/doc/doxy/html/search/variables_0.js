var searchData=
[
  ['a',['a',['../classsp_1_1_i_i_r__filt.html#a033d49e2188e41cf4962ab564f7c8f5c',1,'sp::IIR_filt::a()'],['../group__kalman.html#ga0dc244269951eee6f66c98313d50e05a',1,'sp::KF::A()']]],
  ['a_5fbuf',['a_buf',['../classsp_1_1_i_i_r__filt.html#a724b945ba5e575e3ffa3adb5b82cdb48',1,'sp::IIR_filt']]],
  ['a_5fcur_5fp',['a_cur_p',['../classsp_1_1_i_i_r__filt.html#ae00c806f731d892829191a122a1a6811',1,'sp::IIR_filt']]],
  ['aa_5ffilt',['aa_filt',['../classsp_1_1resampling.html#a5a8f3d9fb99a0e81b37013394782bfb1',1,'sp::resampling']]],
  ['alg',['alg',['../classsp_1_1_f_f_t_w.html#a0dbd3fa3dfb09c078f1463d2211314fe',1,'sp::FFTW']]],
  ['alpha',['alpha',['../group__kalman.html#ga26a03f7ce12a820bcac7f9c9b6b309c9',1,'sp::UKF']]]
];
