var searchData=
[
  ['ukf',['UKF',['../group__kalman.html#ga40a23f3a55bc87eebb5b40d92cefeb98',1,'sp::UKF']]],
  ['unwrap',['unwrap',['../group__math.html#gaddd380ab97652a9c06f71c73978ed10a',1,'sp']]],
  ['update',['update',['../group__kalman.html#gaf24d3805ab22002bef472705ba094a21',1,'sp::KF::update()'],['../group__kalman.html#ga46c8d72ee7960caec05a908b4e0c75ca',1,'sp::EKF::update()'],['../group__kalman.html#ga99a661cbc60cff40e8d4ae7968d62004',1,'sp::UKF::update()']]],
  ['update_5fcoeffs',['update_coeffs',['../classsp_1_1_f_i_r__filt.html#a7224c7982bf0fc81f6b0940cea250792',1,'sp::FIR_filt::update_coeffs()'],['../classsp_1_1_i_i_r__filt.html#a1f5d3244e11f2d6b341910fc0f5100de',1,'sp::IIR_filt::update_coeffs()']]],
  ['update_5fsigma',['update_sigma',['../group__kalman.html#gac19bc4c66c021be37e4bcd8d7ed44c88',1,'sp::UKF']]],
  ['update_5fweights',['update_weights',['../group__kalman.html#gaceea70e7077057286f8f40def8053ee2',1,'sp::UKF']]],
  ['upfir',['upfir',['../classsp_1_1resampling.html#a2ceb924bd798119f01f22590195e526a',1,'sp::resampling']]],
  ['upfirdown',['upfirdown',['../classsp_1_1resampling.html#a7e8012efa703ea72be05095257c1ea69',1,'sp::resampling']]],
  ['upsample',['upsample',['../group__resampling.html#ga175b5728a8b9d4acbf23a834d6d433b6',1,'sp']]],
  ['ut',['ut',['../group__kalman.html#gaead4db2c572c8e0ba9d3928cfefa4ed3',1,'sp::UKF']]]
];
