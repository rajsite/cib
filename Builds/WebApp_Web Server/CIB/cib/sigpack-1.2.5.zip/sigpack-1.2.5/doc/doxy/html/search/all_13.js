var searchData=
[
  ['term',['term',['../classsp_1_1gplot.html#a8db663da49031e7708cb5647ad37598f',1,'sp::gplot']]],
  ['timevec',['timevec',['../group__data.html#ga8659842f116d175a81d846498d472914',1,'sp']]],
  ['timing',['Timing',['../group__timing.html',1,'']]],
  ['timing_2eh',['timing.h',['../timing_8h.html',1,'']]],
  ['title',['title',['../classsp_1_1gplot.html#a1d9080d16f092706dab9d621fd24dd4e',1,'sp::gplot']]],
  ['triang',['triang',['../group__window.html#ga7dea65486f29d367163eb63558869bbc',1,'sp']]],
  ['type',['type',['../classsp_1_1_p_n_m.html#a740cea4f800c8d3cc90f3d5d4bc17dc6',1,'sp::PNM']]]
];
