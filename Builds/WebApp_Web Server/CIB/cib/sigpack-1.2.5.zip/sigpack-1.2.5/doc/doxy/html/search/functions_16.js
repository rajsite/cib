var searchData=
[
  ['xlabel',['xlabel',['../classsp_1_1gplot.html#a4c22b57ea40033580cb4b688f78a1f5f',1,'sp::gplot']]],
  ['xlim',['xlim',['../classsp_1_1gplot.html#a7cfec49f060678c9bd674e7da2921be4',1,'sp::gplot']]]
];
