var searchData=
[
  ['parse_5fcx',['parse_cx',['../classsp_1_1parser.html#ae2481f46a30529b252107b393923c72b',1,'sp::parser']]],
  ['parser',['parser',['../classsp_1_1parser.html#a435c5279a748a8fcbc0efa2c06fe3794',1,'sp::parser']]],
  ['phasez',['phasez',['../group__filter.html#ga318cf2372b0f8dd1a658d0ea2cad6a11',1,'sp']]],
  ['plot_5fadd',['plot_add',['../classsp_1_1gplot.html#aa8a3eae82b921aed1a41e19474420296',1,'sp::gplot::plot_add(const T1 &amp;x, const T2 &amp;y, const std::string lb, const std::string ls=&quot;lines&quot;)'],['../classsp_1_1gplot.html#a6de8d17450b1ba11f8353fc9814619e4',1,'sp::gplot::plot_add(const T1 &amp;y, const std::string lb, const std::string ls=&quot;lines&quot;)']]],
  ['plot_5fadd_5fmat',['plot_add_mat',['../classsp_1_1gplot.html#adfb67d45e6dc58a5eba1f7de0edbfa42',1,'sp::gplot::plot_add_mat(const arma::mat &amp;y)'],['../classsp_1_1gplot.html#a12d5839c9e8e4d22c6f6b8be3a52fe19',1,'sp::gplot::plot_add_mat(const arma::mat &amp;y, const std::string p_lb)']]],
  ['plot_5fclear',['plot_clear',['../classsp_1_1gplot.html#a0b9f993b1189079e1d09d4c407c03a28',1,'sp::gplot']]],
  ['plot_5fshow',['plot_show',['../classsp_1_1gplot.html#a069e7b53091e7007c73452cb66fd5447',1,'sp::gplot']]],
  ['plot_5fstr2',['plot_str2',['../classsp_1_1gplot.html#a071a76426000b75b30c9a87a465df7a9',1,'sp::gplot']]],
  ['pnm',['PNM',['../classsp_1_1_p_n_m.html#a4423e45bb5889802468338c56ec90275',1,'sp::PNM']]],
  ['predict',['predict',['../group__kalman.html#gaee0a1c8fd06d23a516fafc231a7b652b',1,'sp::KF::predict(const arma::mat u)'],['../group__kalman.html#ga9c150cde7e12c6a46ebaf4de998284b3',1,'sp::KF::predict(void)'],['../group__kalman.html#ga0c3f8416a8f0355f7aeabc1f68d7759b',1,'sp::EKF::predict(const arma::mat u)'],['../group__kalman.html#ga6e229b664969e161523d4b1d3d32a3a2',1,'sp::EKF::predict(void)'],['../group__kalman.html#gada968edc7ecf5ccd1606a69078ee9702',1,'sp::UKF::predict(const arma::mat u)'],['../group__kalman.html#ga046c807990ae1b463f586320999d4570',1,'sp::UKF::predict(void)']]],
  ['psd',['psd',['../group__spectrum.html#ga7969e22649ad4f779dbb9423502f86f1',1,'sp::psd(const arma::Col&lt; T1 &gt; &amp;x, const arma::vec &amp;W)'],['../group__spectrum.html#ga947553ad68825673af5a1b6a8dd51eb9',1,'sp::psd(const arma::Col&lt; T1 &gt; &amp;x)']]],
  ['pwelch',['pwelch',['../group__spectrum.html#ga96866dedc8aa1e5fe1768726971af7ff',1,'sp']]],
  ['pwelch_5fph',['pwelch_ph',['../group__spectrum.html#ga2fc18c7ae195e73bc3eda90bb6375d57',1,'sp']]]
];
