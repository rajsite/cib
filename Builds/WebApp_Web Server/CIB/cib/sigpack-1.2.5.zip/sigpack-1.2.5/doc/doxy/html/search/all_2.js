var searchData=
[
  ['c',['C',['../classsp_1_1_f_f_t_w.html#a7ce6cf736719217b46cbf2159e2a26d5',1,'sp::FFTW::C()'],['../group__kalman.html#ga2bab9579cdae744ad1105804f7a51f9d',1,'sp::UKF::C()'],['../classsp_1_1_f_i_r__filt.html#a804ce80510b23309dcb400ca0f327098',1,'sp::FIR_filt::c()']]],
  ['clear',['clear',['../classsp_1_1_f_i_r__filt.html#a18dcb8ee939612a822837f90991c23e0',1,'sp::FIR_filt::clear()'],['../classsp_1_1_i_i_r__filt.html#afee32a34b810f27154d13a6898bf67a7',1,'sp::IIR_filt::clear()'],['../classsp_1_1_p_n_m.html#a981192179bdf56cd61a3f438e0c3a8fb',1,'sp::PNM::clear()'],['../group__kalman.html#ga49743587fa197b9cb77e8b29a247b801',1,'sp::KF::clear()'],['../classsp_1_1_delay.html#a5336f9359b4bcc76b73feea2cbf08211',1,'sp::Delay::clear()']]],
  ['close_5fwindow',['close_window',['../classsp_1_1gplot.html#a35db351e86e3b4bbe1f55e380e38a834',1,'sp::gplot']]],
  ['cols',['cols',['../classsp_1_1_p_n_m.html#a7853f3a9521b2c07f05d317a9303048a',1,'sp::PNM']]],
  ['cos_5fwin',['cos_win',['../group__window.html#ga8ac728241659eeb4ab11ffc86bdbe30c',1,'sp']]],
  ['cur_5fp',['cur_p',['../classsp_1_1_f_i_r__filt.html#ac61bd09c2483538cc708fc72bcbd6d54',1,'sp::FIR_filt::cur_p()'],['../classsp_1_1_delay.html#ae134202d4fec3ca023dee2db73fb748c',1,'sp::Delay::cur_p()']]]
];
