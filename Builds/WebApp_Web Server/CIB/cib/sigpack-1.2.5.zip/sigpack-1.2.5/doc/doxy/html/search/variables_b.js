var searchData=
[
  ['m',['M',['../classsp_1_1_f_i_r__filt.html#a93388cf0f73b4abe964a50b26f508352',1,'sp::FIR_filt::M()'],['../classsp_1_1_i_i_r__filt.html#ab060ce79c6da3410d17207170c0f1118',1,'sp::IIR_filt::M()'],['../group__kalman.html#gab351d86c187cf87c7b0a12ef90fd3933',1,'sp::KF::M()']]],
  ['maxval',['maxval',['../classsp_1_1_p_n_m.html#acf481f9ff2b0e2b64754555ddd58e2d7',1,'sp::PNM']]],
  ['mu',['mu',['../classsp_1_1_f_i_r__filt.html#a415f4ccb54f5cb44f4f1783b1f984c92',1,'sp::FIR_filt']]]
];
