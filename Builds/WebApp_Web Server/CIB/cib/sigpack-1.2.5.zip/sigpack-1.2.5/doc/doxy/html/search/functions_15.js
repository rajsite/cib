var searchData=
[
  ['window',['window',['../classsp_1_1gplot.html#af8a89b7d89ade87f9803ebe99c0110db',1,'sp::gplot::window(const int fig, const char *name, const int x, const int y, const int width, const int height)'],['../classsp_1_1gplot.html#a3a29f27a99a7ca98bca4fda7657afc55',1,'sp::gplot::window(const char *name, const int x, const int y, const int width, const int height)']]],
  ['write',['write',['../classsp_1_1_p_n_m.html#ad40dd41e53832520524bcfbd09d96991',1,'sp::PNM::write(std::string fname, const imtype _type, const arma::cube &amp;img, const std::string info=&quot;&quot;)'],['../classsp_1_1_p_n_m.html#a03c9a701d7940e0c9b35ab10b12791a7',1,'sp::PNM::write(std::string fname, const imtype _type, arma::mat &amp;img, const std::string info=&quot;&quot;)']]],
  ['write_5fheader',['write_header',['../classsp_1_1_p_n_m.html#a5899f832f858a8f400b752f3cb971865',1,'sp::PNM']]]
];
