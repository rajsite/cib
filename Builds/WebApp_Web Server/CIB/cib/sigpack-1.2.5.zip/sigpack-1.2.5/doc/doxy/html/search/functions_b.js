var searchData=
[
  ['label',['label',['../classsp_1_1gplot.html#ae1d38a4f3fe1c41717975a770b25e3f3',1,'sp::gplot']]],
  ['lms_5fadapt',['lms_adapt',['../classsp_1_1_f_i_r__filt.html#a7fd209d72b74561eccca1eb21ca0974a',1,'sp::FIR_filt']]],
  ['lti2discr',['lti2discr',['../namespacesp.html#a096e3d7c69b3cee7d0ed7ff66635ee28',1,'sp']]]
];
