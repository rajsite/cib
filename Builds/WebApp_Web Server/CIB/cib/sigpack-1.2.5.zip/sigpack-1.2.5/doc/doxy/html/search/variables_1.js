var searchData=
[
  ['b',['b',['../classsp_1_1_f_i_r__filt.html#aedda46ec71c95d7e68fb279af9c3e832',1,'sp::FIR_filt::b()'],['../classsp_1_1_i_i_r__filt.html#a1386e87d7bf6d18f7f4ea84def2855bb',1,'sp::IIR_filt::b()'],['../group__kalman.html#ga0b98ff15adf3a2701014eba065e16716',1,'sp::KF::B()']]],
  ['b_5fbuf',['b_buf',['../classsp_1_1_i_i_r__filt.html#abdcb0f475617452b158a5e74a9fb18f3',1,'sp::IIR_filt']]],
  ['b_5fcur_5fp',['b_cur_p',['../classsp_1_1_i_i_r__filt.html#a07fdd197f55e0c529e6437e06249bc21',1,'sp::IIR_filt']]],
  ['beta',['beta',['../group__kalman.html#ga93e6eb3f1b507f1ca266ba3c48dab083',1,'sp::UKF']]],
  ['blk_5fctr',['blk_ctr',['../classsp_1_1_f_i_r__filt.html#a8f11529af751f02972f8c4a82c58600d',1,'sp::FIR_filt']]],
  ['buf',['buf',['../classsp_1_1_f_i_r__filt.html#a60e5fd8e4614af7a13ca7a1b3831449c',1,'sp::FIR_filt::buf()'],['../classsp_1_1_delay.html#a45bb7156a502969ad0cd8f959a85bf3f',1,'sp::Delay::buf()']]]
];
