var searchData=
[
  ['sp_5fversion_5fmajor',['SP_VERSION_MAJOR',['../sigpack_8h.html#a070960494316733ab13995a68a62c59c',1,'sigpack.h']]],
  ['sp_5fversion_5fminor',['SP_VERSION_MINOR',['../sigpack_8h.html#a06816f6a2e4a652dc9af7ea2b2c31046',1,'sigpack.h']]],
  ['sp_5fversion_5fpatch',['SP_VERSION_PATCH',['../sigpack_8h.html#affc7cb2a177e008938bd7dd7c76b86cf',1,'sigpack.h']]]
];
