var searchData=
[
  ['n',['N',['../classsp_1_1_f_f_t_w.html#ac313e4b051fb9a41e8b658eda36c9253',1,'sp::FFTW::N()'],['../classsp_1_1_i_i_r__filt.html#aeb5b949dde67cf16c997b9a3309c7dcc',1,'sp::IIR_filt::N()'],['../group__kalman.html#gac0325a514bb0ab75fa6f9bfa7a23a1ce',1,'sp::KF::N()']]]
];
