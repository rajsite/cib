var searchData=
[
  ['notitle',['notitle',['../index.html',1,'']]],
  ['n',['N',['../classsp_1_1_f_f_t_w.html#ac313e4b051fb9a41e8b658eda36c9253',1,'sp::FFTW::N()'],['../classsp_1_1_i_i_r__filt.html#aeb5b949dde67cf16c997b9a3309c7dcc',1,'sp::IIR_filt::N()'],['../group__kalman.html#gac0325a514bb0ab75fa6f9bfa7a23a1ce',1,'sp::KF::N()']]],
  ['newt_5fadapt',['newt_adapt',['../classsp_1_1_f_i_r__filt.html#a5e0d3ebcd445863adfa4f98322c9eccf',1,'sp::FIR_filt']]],
  ['nlms_5fadapt',['nlms_adapt',['../classsp_1_1_f_i_r__filt.html#a513cc813aae2611bb748dc3470da0812',1,'sp::FIR_filt']]],
  ['notused',['NOTUSED',['../classsp_1_1_p_n_m.html#a5f970fa81d4758dbcfeebc32c20db45ea8fe172b1e1d81d30e302f939b9c6adad',1,'sp::PNM']]]
];
